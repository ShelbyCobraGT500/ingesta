# coding=utf-8
#CODIGO DE LA REGLA DE CALIDAD:CONS_38_001
#GLOSA: EVALUA QUE UNA VARIABLE DE LARGO X
#COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
#PROBADO EN Pyspark
#FECHA MODIFICACION: 07/09/2018
#AUTOR: Marcos Toro Saldia

#CREACIÓN UDF PARA LLAMAR A FUNCIÓN EN PYSAPRK
#df_final = df_new.withColumn("CONS_38_001"},UDF_CONS_38_001(<nombre de las columnas en la cual se debe aplicar la regla>,x(donde x es el tamaño a evaluar)))
#UDF_CONS_38_001 = udf(CONS_38_001,StringType())

#definicion de la funcion para evaluar tamaño del Input
def CONS_38_001(Input1,Input2):
    try:
        if (Input1.strip() == 'SEGUROS') and (Input2.strip() is None or Input2.strip()==''):
            return 1
        else:
            return 0
    except ValueError:  
        return 0

    