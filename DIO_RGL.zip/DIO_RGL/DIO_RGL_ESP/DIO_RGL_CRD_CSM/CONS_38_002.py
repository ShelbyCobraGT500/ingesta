# coding=utf-8
#CODIGO DE LA REGLA DE CALIDAD:CONS_38_002
#GLOSA: EVALUA QUE UNA VARIABLE DE LARGO X
#COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
#PROBADO EN Pyspark
#FECHA MODIFICACION: 07/09/2018
#AUTOR: Marcos Toro Saldia

#CREACIÓN UDF PARA LLAMAR A FUNCIÓN EN PYSAPRK
#df_final = df_new.withColumn("CONS_38_002"},UDF_CONS_38_002(<nombre de las columnas en la cual se debe aplicar la regla>,x(donde x es el tamaño a evaluar)))
#UDF_CONS_38_002 = udf(CONS_38_002,StringType())

#definicion de la funcion para evaluar tamaño del Input
def CONS_38_002(Input1,Input2):
    CODIGO = Input2.strip()[:4]
    try:
        if (Input1.strip() == 'SEGUROS') and (CODIGO in ('0001','0002','0003','0004','0005','0006','0007','0008','0009','0010','0011','0012','0013','0014','0015','0016','0017','0018','0019','0020','0021','0022','0023','0024','0025','0026','0027','0028','0029','0030','0031','0032','0033','0034','0035','0036','0037','0038','0039','0040','0041','0042')):
            return 1
        else:
            return 0
    except ValueError:  
        return 0

    