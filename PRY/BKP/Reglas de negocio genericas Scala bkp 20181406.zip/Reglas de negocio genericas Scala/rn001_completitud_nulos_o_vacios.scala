package reglas_negocio_scala
object funciones extends Serializable {


// CODIGO DE LA REGLA DE CALIDAD: RN001, RN002, RN003
// GLOSA: No puede venir en blanco, No debe tener nulos, No debe venir en blanco/ nulos
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN001_EDC", rn001_completitud_nulos_o_vacio($"NOMBRE DE LA COLUMNA"))

def rn001_completitud_nulos_o_vacio (input: String): String = {
input.toUpperCase.trim match {
  case "" => "0"
  case null => "0"
  case "NULL" => "0"
  case _ => "1"
}
}
}
