package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN124
// GLOSA: 1 o 2
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN00X_EDC", rn124_numerico_uno_o_dos($"NOMBRE DE LA COLUMNA"))

def rn124_numerico_uno_o_dos ( input: String ) : String = {
input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.length == 1 && (List("1","2") contains input) match {
case true => "1"
case false => "0"
}
}
}