package reglas_negocio_scala
object funciones extends Serializable {

// CODIGO DE LA REGLA DE CALIDAD: RN009, RN010, RN011, RN012 , RN013 ,RN014 ,RN015, RN016, RN017
// GLOSA: Numerico de largo X
// COMPLEJIDAD: BAJA (Aplica a 7 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn010_numerico_de_largo_x_udf = udf[String, String, Int](rn010_numerico_de_largo_x)
// val df_new = df.withColumn("rn010", rn010_numerico_de_largo_x_udf($"C2",lit("3")))

def rn010_numerico_de_largo_x (input: String, largo: Int) : String = {
  input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.length == largo match {
    case true => "1"
    case false => "0"
  }
}

}