package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN125
// GLOSA: 1, 3 o 4
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN00X_EDC", rn125_numerico_uno_tres_cuatro($"NOMBRE DE LA COLUMNA"))

def rn125_numerico_uno_tres_cuatro ( input: String ) :String = {
input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.length == 1 && (List("1","3","4") contains input) match {
case true => "1"
case false => "0"
}
}
}