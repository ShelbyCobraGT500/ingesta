package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN035
// GLOSA: S o N
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN027_EDC", rn027_mayor_a_cero($"CREY8090-NUM-OPE"))

def rn035_s_o_n ( input: String ) : String = {
input.length == 1 && (input == "S" || input == "N")  match {
case true => "1"
case false => "0"
}
}
}