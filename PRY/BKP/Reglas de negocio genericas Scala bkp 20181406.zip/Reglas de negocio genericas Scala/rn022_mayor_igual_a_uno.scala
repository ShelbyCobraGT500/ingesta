package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN022
// GLOSA: Mayor o igual a 1
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN022_EDC", rn022_mayor_o_igual_a_uno($"CREY8090-NUM-OPE"))

def rn022_mayor_o_igual_a_uno ( input: String ) : String = {
  input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.toFloat >= 1 match {
	case true => "1"
	case false => "0"
  }
}
}