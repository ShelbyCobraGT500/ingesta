package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN019
// GLOSA: No debe contener decimales.
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn019_no_debe_contener_decimales_udf = udf[String, String](rn019_no_debe_contener_decimales)
// val df_new = df.withColumn("rn019", rn019_no_debe_contener_decimales_udf($"C2"))
def rn019_no_debe_contener_decimales ( input : String) : String = try {
input.matches("\\d[.,]\\d") match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}