package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN006
// GLOSA: No debe tener espacio(s) en blanco o solo ceros.
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn006_no_contenga_espacios_o_solo_ceros ( input : String) : String = {
input.matches("\"(.*?)\"|([^\\s]+)") == false || input.matches("0+") match {
case true => "1"
case false => "0"
}
}
}
