package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN132
// GLOSA: Rut numerico largo 9; Dv Char entre [0-9] o [k]
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn132_rut_numerico_largo_9_dv_char_0_9_k ( input : String, dv : String) : String = try {
(input.length == 9 && input.matches("[0-9]+"))&&(dv.matches("[0-9]+") || dv.matches("[k,K]")) match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}