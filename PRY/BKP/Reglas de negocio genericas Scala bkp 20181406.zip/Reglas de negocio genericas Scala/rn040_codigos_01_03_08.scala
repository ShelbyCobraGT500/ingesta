package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN040
// GLOSA: Codigos 01, 03 o 08
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN00X_EDC", rn040_codigos_01_03_08($"NOMBRE DE LA COLUMNA"))

def rn040_codigos_01_03_08 ( input: String ) :String = {
input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.length == 2 && (List("01","03","08") contains input) match {
case true => "1"
case false => "0"
}
}
}