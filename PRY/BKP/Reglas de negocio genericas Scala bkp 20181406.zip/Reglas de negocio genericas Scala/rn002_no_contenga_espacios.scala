package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN004
// GLOSA: No contenga espacios
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn002_no_contenga_espacios_UDF = udf[String, String](rn002_no_contenga_espacios)
// val df_new = df.withColumn("RN002", rn002_no_contenga_espacios_UDF($"COLUMNA3"))


def rn002_no_contenga_espacios ( input : String) : String = {
input.matches("\"(.*?)\"|([^\\s]+)") == false match {
case true => "1"
case false => "0"
}
}
}
