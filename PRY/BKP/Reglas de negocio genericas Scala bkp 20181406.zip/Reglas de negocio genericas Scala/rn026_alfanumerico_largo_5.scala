package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN026
// GLOSA: Debe ser largo 5 alfanumérico
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN00X_EDC", rn026_alfanumerico_largo_5($"NOMBRE DE LA COLUMNA"))

def rn026_alfanumerico_largo_5 ( input: String ) : String = {
(input.matches("^[a-zA-Z0-9]*$") == true && input.length == 5 ) match {
case true => "1"
case false => "0"
}
}
}