package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN127
// GLOSA: debe contener al menos @ y algun . (punto) posterior
//https://howtodoinjava.com/regex/java-regex-validate-email-address/
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn127_valida_email ( input : String) : String = try {
input.matches("^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$") match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}