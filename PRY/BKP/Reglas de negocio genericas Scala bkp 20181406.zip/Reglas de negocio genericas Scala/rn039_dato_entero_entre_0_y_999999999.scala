package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN039
// GLOSA: Dato Entero entre [0-999.999.999]
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn039_dato_entero_entre_0_y_999999999 ( input : String) : String = try {
input.toInt >= 0 && input.toInt <= 999999999 match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}