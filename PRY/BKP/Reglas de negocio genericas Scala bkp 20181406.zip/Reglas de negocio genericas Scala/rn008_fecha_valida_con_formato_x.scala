package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN008
// GLOSA: fecha valida año-mes-dia
// COMPLEJIDAD: BAJA
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn008_fecha_valida_con_formato_x_UDF = udf[String, String, String](rn008_fecha_valida_con_formato_x)
// val df_new = df.withColumn("RN00X_EDC", rn008_fecha_valida_con_formato_x($"NOMBRE DE LA COLUMNA","yyyy-MM-dd")

def rn008_fecha_valida_con_formato_x(input: String, formato: String): String = try {
val formato_fecha = new java.text.SimpleDateFormat(formato)
input.equals(formato_fecha.format(formato_fecha.parse(input)))
"1"
} catch {
case e: IllegalArgumentException => "0"
}
}