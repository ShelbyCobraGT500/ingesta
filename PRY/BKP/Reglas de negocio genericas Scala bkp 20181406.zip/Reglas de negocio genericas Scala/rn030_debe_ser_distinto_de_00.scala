package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN006
// GLOSA: Debe ser distinto de 00
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn030_debe_ser_distinto_de_00_UDF = udf[String, String](rn030_debe_ser_distinto_de_00)
// val df_new = df.withColumn("RN030", rn030_debe_ser_distinto_de_00_UDF($"C4"))

def rn030_debe_ser_distinto_de_00  ( input : String) : String = {
input != "00" match {
case true => "1"
case false => "0"
}
}
}