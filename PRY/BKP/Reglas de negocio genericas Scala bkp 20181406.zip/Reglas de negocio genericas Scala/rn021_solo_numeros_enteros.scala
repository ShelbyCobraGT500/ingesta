package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN021
// GLOSA: Solo Numeros enteros
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn021_solo_numeros_enteros ( input : String) : String = try {
input.matches("\\d+") match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}