package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN036
// GLOSA: Debe ser mayor o igual a cero
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN036_EDC", rn036_mayor_o_igual_a_cero($"CREY8090-NUM-OPE"))

def rn036_mayor_o_igual_a_cero ( input: String ) : String = {
  input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.toFloat >= 0 match {
	case true => "1"
	case false => "0"
  }
}
}