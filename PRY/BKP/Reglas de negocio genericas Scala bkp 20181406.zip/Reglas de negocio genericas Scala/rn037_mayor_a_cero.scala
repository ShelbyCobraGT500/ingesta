package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN037
// GLOSA: Debe ser mayor a cero.
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN037_EDC", rn037_mayor_a_cero($"CREY8090-NUM-OPE"))

def rn037_mayor_a_cero ( input: String ) : String = {
  input.matches("[-+]?\\d+(\\.\\d+)?") == true && input.toFloat > 0 match {
	case true => "1"
	case false => "0"
  }
}
}