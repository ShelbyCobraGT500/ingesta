package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN043
// GLOSA: Valores entre [0-9]
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn043_valores_entre_0_y_9 ( input : String) : String = try {
input.toFloat >= 0 && input.toFloat <= 9 match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}