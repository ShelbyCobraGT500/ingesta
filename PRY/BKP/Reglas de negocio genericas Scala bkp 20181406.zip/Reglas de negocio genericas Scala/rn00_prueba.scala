package reglas_negocio_scala
//Para compilar el package por linea de comandos es necesario utilizar el siguiente codigo:
//:paste -raw 
//Ctrl-D para finalizar

//El Object disponibiliza las funciones de manera global 
object funciones extends Serializable {
  //Declara funcion de prueba, recibe 1 parametro string
  def rn00_prueba_fn( input:String ) : String = {
      var fin:String = "Hola " + input
      return fin
  }

  //Funcion de prueba 2
  def rn01_prueba_fn( input:String ) : String = {
      var fin:String = "Hola " + input
      return fin
  }
 
  //Another functions 

}  

