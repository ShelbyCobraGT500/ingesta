package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN007
// GLOSA: Valor distinto a 1900-01-01
// COMPLEJIDAD: BAJA
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn007_fecha_distinta_a_1900_01_01_UDF = udf[String, String, String, String](rn007_fecha_distinta_a_1900_01_01)
// val df_new = df.withColumn("RN007", rn007_fecha_distinta_a_1900_01_01_UDF($"C2",$"C3",$"C4"))

def rn007_fecha_distinta_a_1900_01_01(anio: String, mes:String, dia:String): String = try {
val format = new java.text.SimpleDateFormat("yyyyMMdd")
format.parse(anio+mes+dia) != format.parse("19000101") match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}