package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN020
// GLOSA: Debe ser un porcentaje valido (0 a 100, 2 decimales)
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn020_porcentaje_valido ( input : String) : String = try {
((input.toFloat >= 0 && input.toFloat <= 100) && (input.matches("[0-9]+([.][0-9][0-9]?)?"))) match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}