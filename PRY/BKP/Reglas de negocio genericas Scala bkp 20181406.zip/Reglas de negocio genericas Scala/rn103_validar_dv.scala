package reglas_negocio_scala
object funciones extends Serializable {
//Declara funcion de prueba, recibe 1 parametro string
def digits(rut: Int): List[Int] =
rut.toString.toList.map(_.toString.toInt)
 
val integers = Stream.from(0)          // 0, 1, 2, 3, 4, 5, 6, 7, 8, ...
val factors = integers.map(_ % 6 + 2)  // 2, 3, 4, 5, 6, 7, 2, 3, 4, ...
 
implicit class IntOnSteroids(n: Int) {
def mod(d: Int) = ((n % d) + d) % d
}
 
def dv(rut: Int): Char =
-digits(rut).reverse.zip(factors).map { case (a, b) ⇒ a * b }.sum mod 11 match {
  case 10 ⇒ 'k'
  case d  ⇒ d.toString.head
}

def valida_rut ( input : String) : String = try {
val dv_input = input.charAt(input.length() - 1)
val dv_calculado = dv(Integer.parseInt(input.substring(0, input.length() - 1)))
dv_input == dv_calculado match {
case true => "1"
case false => "0"
}} catch {
case e: IllegalArgumentException => "0"
}  

}