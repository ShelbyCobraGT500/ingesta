package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN025
// GLOSA: Debe ser largo 4 alfanumérico
// COMPLEJIDAD: BAJA (Aplica a 1 EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val df_new = df.withColumn("RN00X_EDC", rn025_alfanumerico_largo_4($"NOMBRE DE LA COLUMNA"))

def rn025_alfanumerico_largo_4 ( input: String ) : String = {
(input.matches("^[a-zA-Z0-9]*$") == true && input.length == 4 ) match {
case true => "1"
case false => "0"
}
}
}