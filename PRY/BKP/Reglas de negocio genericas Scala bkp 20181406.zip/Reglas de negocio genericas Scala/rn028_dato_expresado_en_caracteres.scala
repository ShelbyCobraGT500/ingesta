package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN028
// GLOSA: El dato debe estar expresado en caracteres.
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// 

def rn028_dato_expresado_en_caracteres ( input : String) : String = try {
input.matches("\\w+") match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}