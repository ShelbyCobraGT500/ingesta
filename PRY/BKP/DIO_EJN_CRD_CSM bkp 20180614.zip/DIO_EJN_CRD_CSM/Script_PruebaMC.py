# encoding=utf-8
#Para agragra la Carpeta a las variales de entorno lo primero que deben hacer es poner en consola nano ~/.bashrc
#Agregar la siguiente linea export PYTHONPATH=/home/hadoopuser/Escritorio/datalake-be/repository/DIO_RGL/DIO_RGL_GEN
#Cambiar /kibernum/ por user de ustedes y Carpeta donde se almacene el main
#Llamado a funciones necesarias para la realización del script
#hadoop fs -ls /
#hadoop fs -ls /user
#hadoop fs -put /home/hadoopuser/archivo_prueba.txt /user/
#hadoop fs -get /home/hadoopuser/ /user/salida/

from pyspark import SparkContext
from pyspark import SparkConf
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import DoubleType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import SQLContext
from pyspark import sql
from datetime import datetime

import unicodedata
import datetime
import sys


#Importaciones de los paquetes creados que contienen las reglas de negocios
from RGL_GEN_RN001 import RGL_GEN_RN001 as RN001
from RGL_GEN_RN003 import RGL_GEN_RN003 as RN003
from RGL_GEN_RN007 import RGL_GEN_RN007 as RN007
from RGL_GEN_RN008 import RGL_GEN_RN008 as RN008
from RGL_GEN_RN009 import RGL_GEN_RN009 as RN009
from RGL_GEN_RN018 import RGL_GEN_RN018 as RN018
from RGL_GEN_RN019 import RGL_GEN_RN019 as RN019
from RGL_GEN_RN020 import RGL_GEN_RN020 as RN020
from RGL_GEN_RN021 import RGL_GEN_RN021 as RN021
from RGL_GEN_RN022 import RGL_GEN_RN022 as RN022
from RGL_GEN_RN023 import RGL_GEN_RN023 as RN023
from RGL_GEN_RN024 import RGL_GEN_RN024 as RN024
from RGL_GEN_RN026 import RGL_GEN_RN026 as RN026
from RGL_GEN_RN027 import RGL_GEN_RN027 as RN027
from RGL_GEN_RN029 import RGL_GEN_RN029 as RN029
from RGL_GEN_RN030 import RGL_GEN_RN030 as RN030
from RGL_GEN_RN031 import RGL_GEN_RN031 as RN031
from RGL_GEN_RN033 import RGL_GEN_RN033 as RN033
from RGL_GEN_RN034 import RGL_GEN_RN034 as RN034
from RGL_GEN_RN035 import RGL_GEN_RN035 as RN035
from RGL_GEN_RN036 import RGL_GEN_RN036 as RN036
from RGL_GEN_RN037 import RGL_GEN_RN037 as RN037
from RGL_GEN_RN038 import RGL_GEN_RN038 as RN038
from RGL_GEN_RN039 import RGL_GEN_RN039 as RN039
from RGL_GEN_RN040 import RGL_GEN_RN040 as RN040
from RGL_GEN_RN043 import RGL_GEN_RN043 as RN043
from RGL_GEN_RN044 import RGL_GEN_RN044 as RN044
from RGL_GEN_RN045 import RGL_GEN_RN045 as RN045
from RGL_GEN_RN047 import RGL_GEN_RN047 as RN047
from RGL_GEN_RN048 import RGL_GEN_RN048 as RN048
from RGL_GEN_RN049 import RGL_GEN_RN049 as RN049
from RGL_GEN_RN050 import RGL_GEN_RN050 as RN050
from RGL_GEN_RN051 import RGL_GEN_RN051 as RN051
from RGL_GEN_RN052 import RGL_GEN_RN052 as RN052
from RGL_GEN_RN054 import RGL_GEN_RN054 as RN054
from RGL_GEN_RN103 import RGL_GEN_RN103 as RN103
from RGL_GEN_RN124 import RGL_GEN_RN124 as RN124
from RGL_GEN_RN125 import RGL_GEN_RN125 as RN125
from RGL_GEN_RN127 import RGL_GEN_RN127 as RN127

from RGL_BTG_RN004 import RGL_BTG_RN004 as BTG_RN004

#Creación del DataFrame directo desde el archivo.txt
     #Computador Cualquiera

spark = SparkSession \
    .builder \
    .appName("Python Spark SQL basic example") \
    .config("spark.some.config.option", "some-value") \
    .getOrCreate()

#df_a = spark.read.text("/media/sf_Compartida_Clodera/archivo_prueba.txt") #Maquina MC
df_a = spark.read.text("hdfs:///user/archivo_prueba.txt") #Maquina MC

df_new = df_a.select(
    df_a.value.substr(0,25).alias('Correo'),
    df_a.value.substr(26,9).alias('RUT'),
    df_a.value.substr(35,1).alias('DV'),
    df_a.value.substr(36,1).alias('Sexo'),
    df_a.value.substr(37,1).alias('col00'),
    df_a.value.substr(38,1).alias('Codigo_cuenta'),
    df_a.value.substr(39,1).alias('Es_buen_cliente'),
    df_a.value.substr(40,10).alias('Dinero'),
    df_a.value.substr(50,5).alias('col1'),
    df_a.value.substr(55,13).alias('col2'),
    df_a.value.substr(68,3).alias('col3'),
    df_a.value.substr(71,2).alias('col4'),
    df_a.value.substr(73,2).alias('col5'),
    df_a.value.substr(75,3).alias('col6'),
    df_a.value.substr(78,4).alias('col7'),
    df_a.value.substr(82,5).alias('col8'),
    df_a.value.substr(87,9).alias('col9'),
    df_a.value.substr(96,10).alias('col10'),
    df_a.value.substr(106,11).alias('col11'),
    df_a.value.substr(117,15).alias('col12'),
    df_a.value.substr(132,3).alias('col13'),
    df_a.value.substr(135,4).alias('col14'),
    df_a.value.substr(139,3).alias('col15'),
    df_a.value.substr(142,1).alias('col16'),
    df_a.value.substr(143,2).alias('col17'),
    df_a.value.substr(145,4).alias('col18'),
    df_a.value.substr(149,5).alias('col19'),
    df_a.value.substr(154,5).alias('col20'),
    df_a.value.substr(159,8).alias('col21'),
    df_a.value.substr(167,3).alias('col22'),
    df_a.value.substr(170,3).alias('col23'),
    df_a.value.substr(173,2).alias('col24'),
    df_a.value.substr(175,3).alias('col25'),
    df_a.value.substr(178,3).alias('col26'),
    df_a.value.substr(181,1).alias('col27'),
    df_a.value.substr(182,3).alias('col28'),
    df_a.value.substr(185,1).alias('col29'),
    df_a.value.substr(186,2).alias('col30'),
    df_a.value.substr(188,2).alias('col31'),
)

print (df_new.head())
print("Ingrese Regla de Negocios que desee aplicar (Para Esto debe conocer el nombre de las columnas):\n")
print("1.-  RGL_GEN_RN001 : NO DEBE CONTENER NULOS\n")
print("2.-  RGL_GEN_RN003 : NO CONTENGA ESPACIOS\n")
print("3.-  RGL_GEN_RN007 : FECHA DISTINTA A 1900/01/01\n")
print("4.-  RGL_GEN_RN008 : FECHA VALIDA (YYYY-MM-DD)\n")
print("5.-  RGL_GEN_RN009 : EVALUA QUE UNA VARIABLE SEA NUMERICA DE LARGO X (X= 1, 2, 3, 15, 4, 11, 5, 9, 10, 7\n")
print("6.-  RGL_GEN_RN018 : DATO DEBE SER NUMERICO\n")
print("7.-  RGL_GEN_RN019 : NO DEBE TENER DECIMALES\n")
print("8.-  RGL_GEN_RN020 : DEBE SER UN PORCENTAJE VALIDO\n")
print("9.-  RGL_GEN_RN021 : VALIDAR QUE EL DATO SEA ENTERO\n")
print("10.- RGL_GEN_RN022 : DATO DEBE SER MAYOR O IGUAL A 1\n")
print("11.- RGL_GEN_RN023 : LARGO MINIMO UN CARACTER\n")
print("12.- RGL_GEN_RN024 : DATO DEBE SER ALFANUMERICO DE LARGO 3\n")
print("13.- RGL_GEN_RN026 : DATO DEBE SER ALFANUMERICO DE LARGO 5\n")
print("14.- RGL_GEN_RN027 : DATO DEBE SER OBLIGATORIO DE LARGO 8\n")
print("15.- RGL_GEN_RN029 : DATO DEBE SER DISTINTO DE 0\n")
print("16.- RGL_GEN_RN030 : DATO DEBE SER DISTINTO DE 00\n")
print("17.- RGL_GEN_RN031 : DATO DEBE SER DISTINTO DE 000\n")
print("18.- RGL_GEN_RN033 : DATO DEBE SER F O M\n")
print("20.- RGL_GEN_RN034 : VALIDAR SI DATO NUMERICO ES 1, 2, 3, 4 O 9\n")
print("21.- RGL_GEN_RN035 : DATO DEBE SER S O N\n")
print("22.- RGL_GEN_RN036 : EL NUMERO DEBE SER MAYOR O IGUAL A 0\n")
print("23.- RGL_GEN_RN037 : DEBE SER MAYOR A 0\n")
print("24.- RGL_GEN_RN038 : VALIDAR SI DATO NUMERICO ES 1, 2, 3 O 9\n")
print("25.- RGL_GEN_RN039 : VALIDAR SI DATO NUMERICO ES ENTERO ENTRE 0 A 999.999.999\n")
print("26.- RGL_GEN_RN040 : CODIGO DEBE SER 01, 03 O 08\n")
print("27.- RGL_GEN_RN048 : VALIDA SI LA EDAD DEL CLIENTE ES MAYOR A 18 AÑOS EN LA FECHA DE CREACIÓN DEL ARCHIVO\n")
print("28.- RGL_GEN_RN049 : VALIDA SI LA FECHA ES MENOR A LA FECHA DE CREACION DEL ARCHIVO ANALIZADO\n")
print("29.- RGL_GEN_RN050 : VALIDA SI LA FECHA ES MENOR O IGUAL A LA FECHA DE CREACION DEL ARCHIVO ANALIZADO\n")
print("30.- RGL_GEN_RN051 : VALIDA SI EN EL DATO INGRESADO VIENE ALGÚN GUION\n")
print("31.- RGL_GEN_RN052 : VALIDACION QUE EL DATO NO INCLUYA PUNTOS\n")
print("32.- RGL_GEN_RN103 : VALIDACIÓN DEL DIGITO CERIFICADOR DEL RUT\n")
print("33.- RGL_GEN_RN124 : CODIGO DEBE SER 1 O 2\n")
print("34.- RGL_GEN_RN125 : CODIGO DEBE SER 1, 3 O 4\n")
print("35.- RGL_GEN_RN127 : VALIDACIÓN DEL CORREO ELECTRONICO\n")

opcion = int(input("Ingrese su opción: "))

#Creamos variable que tome el nombre de la columna de tipo String
Nom_Columna = "None"

while opcion != 0:
    if opcion == 1:
        print ("Ha ingresado a la regla de negocios RN001\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN001 = udf(RN001,StringType())
        df_final = df_new.withColumn("RN001", UDF_RN001(Nom_Columna))
        df_new = df_final
    elif opcion == 2:
        print ("Ha ingresado a la regla de negocios RN003\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN003 = udf(RN003,StringType())
        df_final = df_new.withColumn("RN003",UDF_RN003(Nom_Columna))
        df_new = df_final
    elif opcion == 3:
        print ("Ha ingresado a la regla de negocios RN007\n")
        Nom_Columna = input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna1= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna2= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna3= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        UDF_RN007= udf(RN007,StringType())
        df_final = df_new.withColumn("RN007",UDF_RN007(Nom_Columna,Nom_Columna1,Nom_Columna2,Nom_Columna3))
        df_new = df_final
    elif opcion == 4:
        print ("Ha ingresado a la regla de negocios RN008\n")
        Nom_Columna = input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna1= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna2= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna3= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        UDF_RN008= udf(RN008,StringType())
        df_final = df_new.withColumn("RN008",UDF_RN008(Nom_Columna,Nom_Columna1,Nom_Columna2,Nom_Columna3))
        df_new = df_final       
    elif opcion == 5:
        print ("Ha ingresado a la regla de negocios RN009\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        Nom_Columna1= input("Ingrese tamaño con el cual desea analizar la columna \n")
        UDF_RN003 = udf(RN003,StringType())
        df_final = df_new.withColumn("RN003",UDF_RN003(Nom_Columna,lit(Nom_Columna1))
        df_new = df_final
    elif opcion == 6:
        print ("Ha ingresado a la regla de negocios RN018\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN018 = udf(RN018,StringType())
        df_final = df_new.withColumn("RN018",UDF_RN018(Nom_Columna))
        df_new = df_final
    elif opcion == 7:
        print ("Ha ingresado a la regla de negocios RN019\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN019 = udf(RN019,StringType())
        df_final = df_new.withColumn("RN019",UDF_RN019(Nom_Columna))
        df_new = df_final
    elif opcion == 8:
        print ("Ha ingresado a la regla de negocios RN020\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN020 = udf(RN020,StringType())
        df_final = df_new.withColumn("RN020",UDF_RN020(Nom_Columna))
        df_new = df_final
    elif opcion == 9:
        print ("Ha ingresado a la regla de negocios RN021\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN021 = udf(RN021,StringType())
        df_final = df_new.withColumn("RN021",UDF_RN021(Nom_Columna))
        df_new = df_final
    elif opcion == 10:
        print ("Ha ingresado a la regla de negocios RN022\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN022 = udf(RN022,StringType())
        df_final = df_new.withColumn("RN022",UDF_RN022(Nom_Columna))
        df_new = df_final
    elif opcion == 11:
        print ("Ha ingresado a la regla de negocios RN023\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN023 = udf(RN023,StringType())
        df_final = df_new.withColumn("RN023",UDF_RN023(Nom_Columna))
        df_new = df_final
    elif opcion == 12:
        print ("Ha ingresado a la regla de negocios RN024\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN024 = udf(RN024,StringType())
        df_final = df_new.withColumn("RN024",UDF_RN024(Nom_Columna))
        df_new = df_final
    elif opcion == 13:
        print ("Ha ingresado a la regla de negocios RN026\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN026 = udf(RN026,StringType())
        df_final = df_new.withColumn("RN026",UDF_RN026(Nom_Columna))
        df_new = df_final
    elif opcion == 14:
        print ("Ha ingresado a la regla de negocios RN027\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN027 = udf(RN027,StringType())
        df_final = df_new.withColumn("RN027",UDF_RN027(Nom_Columna))
        df_new = df_final
    elif opcion == 15:
        print ("Ha ingresado a la regla de negocios RN029\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN029 = udf(RN029,StringType())
        df_final = df_new.withColumn("RN029",UDF_RN029(Nom_Columna))
        df_new = df_final
    elif opcion == 16:
        print ("Ha ingresado a la regla de negocios RN030\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN030 = udf(RN030,StringType())
        df_final = df_new.withColumn("RN030",UDF_RN030(Nom_Columna))
        df_new = df_final
    elif opcion == 17:
        print ("Ha ingresado a la regla de negocios RN031\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN031 = udf(RN031,StringType())
        df_final = df_new.withColumn("RN031",UDF_RN031(Nom_Columna))
        df_new = df_final
    elif opcion == 18:
        print ("Ha ingresado a la regla de negocios RN033\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN033 = udf(RN033,StringType())
        df_final = df_new.withColumn("RN033",UDF_RN033(Nom_Columna))
        df_new = df_final
    elif opcion == 19:
        print ("Ha ingresado a la regla de negocios RN034\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN034 = udf(RN034,StringType())
        df_final = df_new.withColumn("RN034",UDF_RN034(Nom_Columna))
        df_new = df_final
    elif opcion == 20:
        print ("Ha ingresado a la regla de negocios RN035\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN035 = udf(RN035,StringType())
        df_final = df_new.withColumn("RN035",UDF_RN035(Nom_Columna))
        df_new = df_final
    elif opcion == 21:
        print ("Ha ingresado a la regla de negocios RN036\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN036 = udf(RN036,StringType())
        df_final = df_new.withColumn("RN036",UDF_RN036(Nom_Columna))
        df_new = df_final
    elif opcion == 22:
        print ("Ha ingresado a la regla de negocios RN037\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN037 = udf(RN037,StringType())
        df_final = df_new.withColumn("RN037",UDF_RN037(Nom_Columna))
        df_new = df_final
    elif opcion == 23:
        print ("Ha ingresado a la regla de negocios RN038\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN038 = udf(RN038,StringType())
        df_final = df_new.withColumn("RN038",UDF_RN038(Nom_Columna))
        df_new = df_final
    elif opcion == 24:
        print ("Ha ingresado a la regla de negocios RN039\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN039 = udf(RN039,StringType())
        df_final = df_new.withColumn("RN039",UDF_RN039(Nom_Columna))
        df_new = df_final
    elif opcion == 25:
        print ("Ha ingresado a la regla de negocios RN040\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN040 = udf(RN040,StringType())
        df_final = df_new.withColumn("RN040",UDF_RN040(Nom_Columna))
        df_new = df_final
    elif opcion == 26:
        print ("Ha ingresado a la regla de negocios RN048\n")
        Nom_Columna = input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna1= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna2= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna3= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        UDF_RN048= udf(RN048,StringType())
        df_final = df_new.withColumn("RN048",UDF_RN048(Nom_Columna,Nom_Columna1,Nom_Columna2,Nom_Columna3))
        df_new = df_final
    elif opcion == 27:
        print ("Ha ingresado a la regla de negocios RN049\n")
        Nom_Columna = input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna1= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna2= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna3= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        UDF_RN049= udf(RN049,StringType())
        df_final = df_new.withColumn("RN049",UDF_RN049(Nom_Columna,Nom_Columna1,Nom_Columna2,Nom_Columna3))
        df_new = df_final
    elif opcion == 28:
        print ("Ha ingresado a la regla de negocios RN050\n")
        Nom_Columna = input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna1= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna2= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        Nom_Columna3= input("Introduzca Las Columnas a aplicar regla de negocios: \n")
        UDF_RN050= udf(RN050,StringType())
        df_final = df_new.withColumn("RN050",UDF_RN050(Nom_Columna,Nom_Columna1,Nom_Columna2,Nom_Columna3))
        df_new = df_final
    elif opcion == 29:
        print ("Ha ingresado a la regla de negocios RN051\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN051 = udf(RN051,StringType())
        df_final = df_new.withColumn("RN051",UDF_RN051(Nom_Columna))
        df_new = df_final
    elif opcion == 30:
        print ("Ha ingresado a la regla de negocios RN052\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN052 = udf(RN052,StringType())
        df_final = df_new.withColumn("RN052",UDF_RN052(Nom_Columna))
        df_new = df_final
    elif opcion == 31:
        print ("Ha ingresado a la regla de negocios RN103\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        Nom_Columna1= input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN103 = udf(RN103,StringType())
        df_final = df_new.withColumn("RN103",UDF_RN103(Nom_Columna,Nom_Columna1))
        df_new = df_final
    elif opcion == 32:
        print ("Ha ingresado a la regla de negocios RN124\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN124 = udf(RN124,StringType())
        df_final = df_new.withColumn("RN124",UDF_RN124(Nom_Columna))
        df_new = df_final
    elif opcion == 32:
        print ("Ha ingresado a la regla de negocios RN125\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN125 = udf(RN125,StringType())
        df_final = df_new.withColumn("RN125",UDF_RN125(Nom_Columna))
        df_new = df_final
    elif opcion == 33:
        print ("Ha ingresado a la regla de negocios RN127\n")
        Nom_Columna = input("Introduzca Columna a aplicar regla de negocios: \n")
        UDF_RN127 = udf(RN127,StringType())
        df_final = df_new.withColumn("RN127",UDF_RN127(Nom_Columna))
        df_new = df_final
    print("Ingrese Nuevamente Regla de Negocios que desee aplicar (Para Esto debe conocer el nombre de las columnas):\n")
    print("1.-  RGL_GEN_RN001 : NO DEBE CONTENER NULOS\n")
    print("2.-  RGL_GEN_RN003 : NO CONTENGA ESPACIOS\n")
    print("3.-  RGL_GEN_RN007 : FECHA DISTINTA A 1900/01/01\n")
    print("4.-  RGL_GEN_RN008 : FECHA VALIDA (YYYY-MM-DD)\n")
    print("5.-  RGL_GEN_RN009 : EVALUA QUE UNA VARIABLE SEA NUMERICA DE LARGO X (X= 1, 2, 3, 15, 4, 11, 5, 9, 10, 7\n")
    print("6.-  RGL_GEN_RN018 : DATO DEBE SER NUMERICO\n")
    print("7.-  RGL_GEN_RN019 : NO DEBE TENER DECIMALES\n")
    print("8.-  RGL_GEN_RN020 : DEBE SER UN PORCENTAJE VALIDO\n")
    print("9.-  RGL_GEN_RN021 : VALIDAR QUE EL DATO SEA ENTERO\n")
    print("10.- RGL_GEN_RN022 : DATO DEBE SER MAYOR O IGUAL A 1\n")
    print("11.- RGL_GEN_RN023 : LARGO MINIMO UN CARACTER\n")
    print("12.- RGL_GEN_RN024 : DATO DEBE SER ALFANUMERICO DE LARGO 3\n")
    print("13.- RGL_GEN_RN026 : DATO DEBE SER ALFANUMERICO DE LARGO 5\n")
    print("14.- RGL_GEN_RN027 : DATO DEBE SER OBLIGATORIO DE LARGO 8\n")
    print("15.- RGL_GEN_RN029 : DATO DEBE SER DISTINTO DE 0\n")
    print("16.- RGL_GEN_RN030 : DATO DEBE SER DISTINTO DE 00\n")
    print("17.- RGL_GEN_RN031 : DATO DEBE SER DISTINTO DE 000\n")
    print("18.- RGL_GEN_RN033 : DATO DEBE SER F O M\n")
    print("20.- RGL_GEN_RN034 : VALIDAR SI DATO NUMERICO ES 1, 2, 3, 4 O 9\n")
    print("21.- RGL_GEN_RN035 : DATO DEBE SER S O N\n")
    print("22.- RGL_GEN_RN036 : EL NUMERO DEBE SER MAYOR O IGUAL A 0\n")
    print("23.- RGL_GEN_RN037 : DEBE SER MAYOR A 0\n")
    print("24.- RGL_GEN_RN038 : VALIDAR SI DATO NUMERICO ES 1, 2, 3 O 9\n")
    print("25.- RGL_GEN_RN039 : VALIDAR SI DATO NUMERICO ES ENTERO ENTRE 0 A 999.999.999\n")
    print("26.- RGL_GEN_RN040 : CODIGO DEBE SER 01, 03 O 08\n")
    print("27.- RGL_GEN_RN048 : VALIDA SI LA EDAD DEL CLIENTE ES MAYOR A 18 AÑOS EN LA FECHA DE CREACIÓN DEL ARCHIVO\n")
    print("28.- RGL_GEN_RN049 : VALIDA SI LA FECHA ES MENOR A LA FECHA DE CREACION DEL ARCHIVO ANALIZADO\n")
    print("29.- RGL_GEN_RN050 : VALIDA SI LA FECHA ES MENOR O IGUAL A LA FECHA DE CREACION DEL ARCHIVO ANALIZADO\n")
    print("30.- RGL_GEN_RN051 : VALIDA SI EN EL DATO INGRESADO VIENE ALGÚN GUION\n")
    print("31.- RGL_GEN_RN052 : VALIDACION QUE EL DATO NO INCLUYA PUNTOS\n")
    print("32.- RGL_GEN_RN103 : VALIDACIÓN DEL DIGITO CERIFICADOR DEL RUT\n")
    print("33.- RGL_GEN_RN124 : CODIGO DEBE SER 1 O 2\n")
    print("34.- RGL_GEN_RN125 : CODIGO DEBE SER 1, 3 O 4\n")
    print("35.- RGL_GEN_RN127 : VALIDACIÓN DEL CORREO ELECTRONICO\n")
    opcion = int(input("Ingrese su opción: "))
df_new.write.csv('/media/sf_Compartida_Clodera/RN040',header='true')
col30