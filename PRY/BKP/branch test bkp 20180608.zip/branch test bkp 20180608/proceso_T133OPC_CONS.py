#Llamado a funciones necesarias para la realización del script

from pyspark import SparkContext
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import DoubleType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql import functions as F
from datetime import datetime
import unicodedata
import datetime

#Importaciones de los paquetes creados que contienen las reglas de negocios

import ReglasNegocios.rn001_completitud_sin_nulos as rn001
import ReglasNegocios.rn036_mayor_o_igual_0 as rn036
import ReglasNegocios.rn007_distinto_a_1900_01_01 as rn007
import ReglasNegocios.rn009_valor_num_tam_x as rn009
import ReglasNegocios.rn019_No_debe_tener_decimales as rn019
import ReglasNegocios.rn029_debe_ser_diferente_0 as rn029
import ReglasNegocios.rn030_debe_ser_diferente_00 as rn030
import ReglasNegocios.rn031_debe_ser_diferente_000 as rn031
import ReglasNegocios.rn018_debe_ser_numerico as rn018
import ReglasNegocios.rn037_dato_mayor_a_cero as rn037
import ReglasNegocios.rn003_dato_NO_contiene_blanco as rn003
import ReglasNegocios.rn006_dato_NO_contiene_blanco_o_solo_0 as rn006
import ReglasNegocios.rn022_dato_mayor_igual_a_uno as rn022
import ReglasNegocios.rn020_debe_porcentaje_valido as rn020
import ReglasNegocios.rn026_alfanumerico_largo_5 as rn026
import ReglasNegocios.rn025_alfanumerico_largo_4 as rn025
import ReglasNegocios.rn027_largo_de_8 as rn027
import ReglasNegocios.rn033_F_o_M as rn033
import ReglasNegocios.rn043_0_9 as rn043
import ReglasNegocios.rn040_0103o08 as rn040
import ReglasNegocios.rn124_1o2 as rn124
import ReglasNegocios.rn125_1_3_o_4 as rn125
import ReglasNegocios.rn132_rut_largo_9_dv_0_9_o_k as rn132
import ReglasNegocios.rn127_validar_mail as rn127
import ReglasNegocios.rn103_validar_dv as rn103
import ReglasNegocios.rn034_validar_N12349 as rn034
import ReglasNegocios.rn039_entero_entre_0_a_999M as rn039
import ReglasNegocios.rn024_alfanumerico_largo_3 as rn024
import ReglasNegocios.rn005_ni_puntos_ni_guiones as rn005
import ReglasNegocios.rn035_S_o_N as rn035
import ReglasNegocios.rn038_validar_entero_1239 as rn038
import ReglasNegocios.rn032_dato_mayor_a_cero_y_menor_a_100 as rn032
import ReglasNegocios.rn028_dato_expresado_en_caracteres as rn028
import ReglasNegocios.rn021_solo_dato_entero as rn021
import ReglasNegocios.rn023_largo_minimo_un_caracter as rn023
import ReglasNegocios.rn008_fecha_valida_yyyy_mm_dd as rn008
import ReglasNegocios.rn052_No_puntos as rn052
import ReglasNegocios.rn051_No_guion as rn051
import ReglasNegocios.rn048_NO_menor_a_18_anos as rn048
import ReglasNegocios.rn050_NO_mayor_fec_ejec as rn050
import ReglasNegocios.rn049_NO_mayor_o_igual_fec_ejec as rn049
import sys

sys.path.append('../../')
#Creación del DataFrame directo desde el archivo.txt
     #Computador Cualquiera

df_a = sqlContext.read.text("hdfs:///user/cloudera/prueba2.txt") #Maquina Nicolas

df_new = df_a.select(
    df_a.value.substr(0,25).alias('Correo'),
    df_a.value.substr(26,8).alias('RUT'),
    df_a.value.substr(34,1).alias('DV'),
    df_a.value.substr(35,1).alias('Sexo'),
    df_a.value.substr(36,1).alias('Miercoles'),
    df_a.value.substr(37,1).alias('Codigo_cuenta'),
    df_a.value.substr(38,1).alias('Es_buen_cliente'),
    df_a.value.substr(39,10).alias('Dinerouuu'),
    df_a.value.substr(49,5).alias('mmmmmm'),
    df_a.value.substr(54,13).alias('validoooo'),
    df_a.value.substr(67,3).alias('pipi'),
    )

#Creación del dataframe con las columnas correspondientes para el archivo T133OPC_CONS.txt
df_new= df_a.select(
    df_a.value.substr(0,11).alias('CREY8090-NUM-OPE'),
    df_a.value.substr(12,4).alias('CREY8090-CTA-CPD'),
    df_a.value.substr(16,3).alias('CREY8090-COD-MON'),
    df_a.value.substr(19,3).alias('CREY8090-OFI-DES'),
    df_a.value.substr(22,3).alias('CREY8090-FNL-PRD'),
    df_a.value.substr(25,3).alias('CREY8090-OBJ-PRD'),
    df_a.value.substr(28,3).alias('CREY8090-ATZ-INI'),
    df_a.value.substr(31,15).alias('CREY8090-MNT-ORG'),
    df_a.value.substr(46,14).alias('CREY8090-MNT-OPE'),
    df_a.value.substr(60,2).alias('CREY8090-FEC-SIO-ORG'),
    df_a.value.substr(62,2).alias('CREY8090-FEC-ANO-ORG'),
    df_a.value.substr(64,2).alias('CREY8090-FEC-MES-ORG'),
    df_a.value.substr(66,2).alias('CREY8090-FEC-DIA-ORG'),
    df_a.value.substr(68,2).alias('CREY8090-FEC-SIO-CTB'),
    df_a.value.substr(70,2).alias('CREY8090-FEC-ANO-CTB'),
    df_a.value.substr(72,2).alias('CREY8090-FEC-MES-CTB'),
    df_a.value.substr(74,2).alias('CREY8090-FEC-DIA-CTB'),
    df_a.value.substr(76,2).alias('CREY8090-FEC-SIO-DVG'),
    df_a.value.substr(78,2).alias('CREY8090-FEC-ANO-DVG'),
    df_a.value.substr(80,2).alias('CREY8090-FEC-MES-DVG'),
    df_a.value.substr(82,2).alias('CREY8090-FEC-DIA-DVG'),
    df_a.value.substr(84,2).alias('CREY8090-FEC-SIO-PEN'),
    df_a.value.substr(86,2).alias('CREY8090-FEC-ANO-PEN'),
    df_a.value.substr(88,2).alias('CREY8090-FEC-MES-PEN'),
    df_a.value.substr(90,2).alias('CREY8090-FEC-DIA-PEN'),
    df_a.value.substr(92,1).alias('CREY8090-TRT'),
    df_a.value.substr(93,2).alias('CREY8090-COD-REG'),
    df_a.value.substr(95,1).alias('CREY8090-TIP-TAS'),
    df_a.value.substr(96,9).alias('CREY8090-TAS-PAC'),
    df_a.value.substr(105,3).alias('CREY8090-BAS-TAS'),
    df_a.value.substr(108,1).alias('CREY8090-CMR-TAS'),
    df_a.value.substr(109,6).alias('CREY8090-TBL-PAG-UNO'),
    df_a.value.substr(115,6).alias('CREY8090-TBL-PAG-DOS'),
    df_a.value.substr(121,1).alias('CREY8090-COD-PEN'),
    df_a.value.substr(122,9).alias('CREY8090-TAS-PEN'),
    df_a.value.substr(131,6).alias('CREY8090-TBS-PEN'),
    df_a.value.substr(137,1).alias('CREY8090-CAR-GEN'),
    df_a.value.substr(138,12).alias('CREY8090-CTA-CGO'),
    df_a.value.substr(150,3).alias('CREY8090-TIP-DLG'),
    df_a.value.substr(153,6).alias('CREY8090-NUM-PAG'),
    df_a.value.substr(159,1).alias('CREY8090-COB-SEG'),
    df_a.value.substr(160,1).alias('CREY8090-COD-SUS'),
    df_a.value.substr(161,2).alias('CREY8090-FEC-SIO-SUS'),
    df_a.value.substr(163,2).alias('CREY8090-FEC-ANO-SUS'),
    df_a.value.substr(165,2).alias('CREY8090-FEC-MES-SUS'),
    df_a.value.substr(167,2).alias('CREY8090-FEC-DIA-SUS'),
    df_a.value.substr(169,2).alias('CREY8090-FEC-SIO-SUM'),
    df_a.value.substr(171,2).alias('CREY8090-FEC-ANO-SUM'),
    df_a.value.substr(173,2).alias('CREY8090-FEC-MES-SUM'),
    df_a.value.substr(175,2).alias('CREY8090-FEC-DIA-SUM'),
    df_a.value.substr(177,1).alias('CREY8090-EST-OPE'),
    df_a.value.substr(178,3).alias('CREY8090-CC'),
    df_a.value.substr(181,17).alias('CREY8090-SDO-CPD'),
    df_a.value.substr(198,4).alias('CREY8090-PLA'),
    df_a.value.substr(202,2).alias('CREY8090-DIA-PAG'),
    df_a.value.substr(204,1).alias('CREY8090-VGT-TIT'),
    df_a.value.substr(205,2).alias('CREY8090-FEC-SIO-MVT'),
    df_a.value.substr(207,2).alias('CREY8090-FEC-ANO-MVT'),
    df_a.value.substr(209,2).alias('CREY8090-FEC-MES-MVT'),
    df_a.value.substr(211,2).alias('CREY8090-FEC-DIA-MVT'),
    df_a.value.substr(213,2).alias('CREY8090-FEC-SIO-PRD'),
    df_a.value.substr(215,2).alias('CREY8090-FEC-ANO-PRD'),
    df_a.value.substr(217,2).alias('CREY8090-FEC-MES-PRD'),
    df_a.value.substr(219,2).alias('CREY8090-FEC-DIA-PRD'),
    df_a.value.substr(221,1).alias('CREY8090-ANL-FRD'),
    df_a.value.substr(222,3).alias('CREY8090-NUM-GVM'),
    df_a.value.substr(225,8).alias('CREY8090-FEC-ETN'),
    df_a.value.substr(233,1).alias('CREY8090-CUO-IGU'),
    df_a.value.substr(234,2).alias('CREY8090-TAS-CLC'),
    df_a.value.substr(236,3).alias('CREY8090-MNT-CSD'),
    df_a.value.substr(239,8).alias('CREY8090-FEC-ACT'),
    df_a.value.substr(247,8).alias('CREY8090-FEC-TEO'),
    df_a.value.substr(255,6).alias('CREY8090-FEC-OTO'),
    df_a.value.substr(261,4).alias('CREY8090-UNI-GES'),
    df_a.value.substr(265,10).alias('CREY8090-BLT-GAR'),
    df_a.value.substr(275,1).alias('CREY8090-RIE-ORG'),
    df_a.value.substr(276,4).alias('CREY8090-POR-FON'),
    df_a.value.substr(280,3).alias('CREY8090-COD-CAI'),
    df_a.value.substr(283,8).alias('CREY8090-FEC-FIR'),
    df_a.value.substr(291,6).alias('CREY8090-LIN-CRD'),
    df_a.value.substr(297,14).alias('CREY8090-MNT-NMN'),
    df_a.value.substr(311,7).alias('CREY8090-TAS-TBJ'),
    df_a.value.substr(318,14).alias('CREY8090-MNT-ACU'),
    df_a.value.substr(332,14).alias('CREY8090-MTO-ACL'),
    df_a.value.substr(346,1).alias('CREY8090-TIP-AVS'),
    df_a.value.substr(347,15).alias('CREY8090-SDO-CPL-TEO'),
    df_a.value.substr(362,15).alias('CREY8090-SDO-ORG'),
    df_a.value.substr(377,15).alias('CREY8090-SDO-ORG-PES'),
    df_a.value.substr(392,15).alias('CREY8090-SDO-VCD'),
    df_a.value.substr(407,15).alias('CREY8090-SDO-VCD-PES'),
    df_a.value.substr(422,15).alias('CREY8090-SDO-CBR-JUD'),
    df_a.value.substr(437,15).alias('CREY8090-SDO-CBR-JUD-PE'),
    df_a.value.substr(452,15).alias('CREY8090-SDO-CST'),
    df_a.value.substr(467,15).alias('CREY8090-SDO-CST-PES'),
    df_a.value.substr(482,3).alias('CREY8090-TIP-PMO')
)

print("Ingrese Regla de Negocios que desee aplicar (Para Esto debe conocer el nombre de las columnas):\n")
print("1.- Regla de Negocios rn_001 : Completitud sin Nulos o Vacíos\n")
print("2.- Regla de Negocios rn_003 : Número mayor o igual a 0\n")
opcion = int(input("Ingrese su opción: "))

#Creamos variable que tome el nombre de la columna de tipo String
Nom_Columna = "None"


while opcion != 0:
    if opcion == 1:
        print ("Ha ingresado a la regla de negocios rn_001\n")
        print (input("Introduzca Columna a aplicar regla de negocios: \n"))
    elif opcion == 2:
        print ()
    print("Ingrese nuevamente Regla de Negocios que desee aplicar (Para Esto debe conocer el nombre de las columnas):\n")
    print("1.- Regla Negocios rn_001 : Completitud sin Nulos o Vacíos")
    opcion = int(input("Ingrese su opción: "))
