#Llamado a funciones necesarias para la realización del script

from pyspark import SparkContext
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import DoubleType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql import functions as F
from datetime import datetime
import unicodedata
import datetime
import sys


sys.path.append('../../')

#Importaciones de los paquetes creados que contienen las reglas de negocios
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN001 import RGL_GEN_RN001 as RN001
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN003 import RGL_GEN_RN003 as RN003
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN004 import RGL_GEN_RN004 as RN004
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN005 import RGL_GEN_RN005 as RN005
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN006 import RGL_GEN_RN006 as RN006
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN007 import RGL_GEN_RN007 as RN007
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN008 import RGL_GEN_RN008 as RN008
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN009 import RGL_GEN_RN009 as RN009
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN018 import RGL_GEN_RN018 as RN018
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN019 import RGL_GEN_RN019 as RN019
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN020 import RGL_GEN_RN020 as RN020
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN021 import RGL_GEN_RN021 as RN021
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN022 import RGL_GEN_RN022 as RN022
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN023 import RGL_GEN_RN023 as RN023
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN024 import RGL_GEN_RN024 as RN024
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN025 import RGL_GEN_RN025 as RN025
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN026 import RGL_GEN_RN026 as RN026
from DIO_RGL.DIO_RGL_GEN.RGL_GEN_RN027 import RGL_GEN_RN027 as RN027


#Creación del DataFrame directo desde el archivo.txt
     #Computador Cualquiera

DF_T133OPC_CONS = sqlContext.read.text("hdfs:///user/cloudera/prueba2.txt") #Maquina Nicolas

df_new = DF_T133OPC_CONS.select(
    DF_T133OPC_CONS.value.substr(0,25).alias('Correo'),
    DF_T133OPC_CONS.value.substr(26,8).alias('RUT'),
    DF_T133OPC_CONS.value.substr(34,1).alias('DV'),
    DF_T133OPC_CONS.value.substr(35,1).alias('Sexo'),
    DF_T133OPC_CONS.value.substr(36,1).alias('Miercoles'),
    DF_T133OPC_CONS.value.substr(37,1).alias('Codigo_cuenta'),
    DF_T133OPC_CONS.value.substr(38,1).alias('Es_buen_cliente'),
    DF_T133OPC_CONS.value.substr(39,10).alias('Dinerouuu'),
    DF_T133OPC_CONS.value.substr(49,5).alias('mmmmmm'),
    DF_T133OPC_CONS.value.substr(54,13).alias('validoooo'),
    DF_T133OPC_CONS.value.substr(67,3).alias('pipi'),
    )

#Creación del dataframe con las columnas correspondientes para el archivo T133OPC_CONS.txt
df_new= DF_T133OPC_CONS.select(
    DF_T133OPC_CONS.value.substr(0,11).alias('CREY8090-NUM-OPE'),
    DF_T133OPC_CONS.value.substr(12,4).alias('CREY8090-CTA-CPD'),
    DF_T133OPC_CONS.value.substr(16,3).alias('CREY8090-COD-MON'),
    DF_T133OPC_CONS.value.substr(19,3).alias('CREY8090-OFI-DES'),
    DF_T133OPC_CONS.value.substr(22,3).alias('CREY8090-FNL-PRD'),
    DF_T133OPC_CONS.value.substr(25,3).alias('CREY8090-OBJ-PRD'),
    DF_T133OPC_CONS.value.substr(28,3).alias('CREY8090-ATZ-INI'),
    DF_T133OPC_CONS.value.substr(31,15).alias('CREY8090-MNT-ORG'),
    DF_T133OPC_CONS.value.substr(46,14).alias('CREY8090-MNT-OPE'),
    DF_T133OPC_CONS.value.substr(60,2).alias('CREY8090-FEC-SIO-ORG'),
    DF_T133OPC_CONS.value.substr(62,2).alias('CREY8090-FEC-ANO-ORG'),
    DF_T133OPC_CONS.value.substr(64,2).alias('CREY8090-FEC-MES-ORG'),
    DF_T133OPC_CONS.value.substr(66,2).alias('CREY8090-FEC-DIA-ORG'),
    DF_T133OPC_CONS.value.substr(68,2).alias('CREY8090-FEC-SIO-CTB'),
    DF_T133OPC_CONS.value.substr(70,2).alias('CREY8090-FEC-ANO-CTB'),
    DF_T133OPC_CONS.value.substr(72,2).alias('CREY8090-FEC-MES-CTB'),
    DF_T133OPC_CONS.value.substr(74,2).alias('CREY8090-FEC-DIA-CTB'),
    DF_T133OPC_CONS.value.substr(76,2).alias('CREY8090-FEC-SIO-DVG'),
    DF_T133OPC_CONS.value.substr(78,2).alias('CREY8090-FEC-ANO-DVG'),
    DF_T133OPC_CONS.value.substr(80,2).alias('CREY8090-FEC-MES-DVG'),
    DF_T133OPC_CONS.value.substr(82,2).alias('CREY8090-FEC-DIA-DVG'),
    DF_T133OPC_CONS.value.substr(84,2).alias('CREY8090-FEC-SIO-PEN'),
    DF_T133OPC_CONS.value.substr(86,2).alias('CREY8090-FEC-ANO-PEN'),
    DF_T133OPC_CONS.value.substr(88,2).alias('CREY8090-FEC-MES-PEN'),
    DF_T133OPC_CONS.value.substr(90,2).alias('CREY8090-FEC-DIA-PEN'),
    DF_T133OPC_CONS.value.substr(92,1).alias('CREY8090-TRT'),
    DF_T133OPC_CONS.value.substr(93,2).alias('CREY8090-COD-REG'),
    DF_T133OPC_CONS.value.substr(95,1).alias('CREY8090-TIP-TAS'),
    DF_T133OPC_CONS.value.substr(96,9).alias('CREY8090-TAS-PAC'),
    DF_T133OPC_CONS.value.substr(105,3).alias('CREY8090-BAS-TAS'),
    DF_T133OPC_CONS.value.substr(108,1).alias('CREY8090-CMR-TAS'),
    DF_T133OPC_CONS.value.substr(109,6).alias('CREY8090-TBL-PAG-UNO'),
    DF_T133OPC_CONS.value.substr(115,6).alias('CREY8090-TBL-PAG-DOS'),
    DF_T133OPC_CONS.value.substr(121,1).alias('CREY8090-COD-PEN'),
    DF_T133OPC_CONS.value.substr(122,9).alias('CREY8090-TAS-PEN'),
    DF_T133OPC_CONS.value.substr(131,6).alias('CREY8090-TBS-PEN'),
    DF_T133OPC_CONS.value.substr(137,1).alias('CREY8090-CAR-GEN'),
    DF_T133OPC_CONS.value.substr(138,12).alias('CREY8090-CTA-CGO'),
    DF_T133OPC_CONS.value.substr(150,3).alias('CREY8090-TIP-DLG'),
    DF_T133OPC_CONS.value.substr(153,6).alias('CREY8090-NUM-PAG'),
    DF_T133OPC_CONS.value.substr(159,1).alias('CREY8090-COB-SEG'),
    DF_T133OPC_CONS.value.substr(160,1).alias('CREY8090-COD-SUS'),
    DF_T133OPC_CONS.value.substr(161,2).alias('CREY8090-FEC-SIO-SUS'),
    DF_T133OPC_CONS.value.substr(163,2).alias('CREY8090-FEC-ANO-SUS'),
    DF_T133OPC_CONS.value.substr(165,2).alias('CREY8090-FEC-MES-SUS'),
    DF_T133OPC_CONS.value.substr(167,2).alias('CREY8090-FEC-DIA-SUS'),
    DF_T133OPC_CONS.value.substr(169,2).alias('CREY8090-FEC-SIO-SUM'),
    DF_T133OPC_CONS.value.substr(171,2).alias('CREY8090-FEC-ANO-SUM'),
    DF_T133OPC_CONS.value.substr(173,2).alias('CREY8090-FEC-MES-SUM'),
    DF_T133OPC_CONS.value.substr(175,2).alias('CREY8090-FEC-DIA-SUM'),
    DF_T133OPC_CONS.value.substr(177,1).alias('CREY8090-EST-OPE'),
    DF_T133OPC_CONS.value.substr(178,3).alias('CREY8090-CC'),
    DF_T133OPC_CONS.value.substr(181,17).alias('CREY8090-SDO-CPD'),
    DF_T133OPC_CONS.value.substr(198,4).alias('CREY8090-PLA'),
    DF_T133OPC_CONS.value.substr(202,2).alias('CREY8090-DIA-PAG'),
    DF_T133OPC_CONS.value.substr(204,1).alias('CREY8090-VGT-TIT'),
    DF_T133OPC_CONS.value.substr(205,2).alias('CREY8090-FEC-SIO-MVT'),
    DF_T133OPC_CONS.value.substr(207,2).alias('CREY8090-FEC-ANO-MVT'),
    DF_T133OPC_CONS.value.substr(209,2).alias('CREY8090-FEC-MES-MVT'),
    DF_T133OPC_CONS.value.substr(211,2).alias('CREY8090-FEC-DIA-MVT'),
    DF_T133OPC_CONS.value.substr(213,2).alias('CREY8090-FEC-SIO-PRD'),
    DF_T133OPC_CONS.value.substr(215,2).alias('CREY8090-FEC-ANO-PRD'),
    DF_T133OPC_CONS.value.substr(217,2).alias('CREY8090-FEC-MES-PRD'),
    DF_T133OPC_CONS.value.substr(219,2).alias('CREY8090-FEC-DIA-PRD'),
    DF_T133OPC_CONS.value.substr(221,1).alias('CREY8090-ANL-FRD'),
    DF_T133OPC_CONS.value.substr(222,3).alias('CREY8090-NUM-GVM'),
    DF_T133OPC_CONS.value.substr(225,8).alias('CREY8090-FEC-ETN'),
    DF_T133OPC_CONS.value.substr(233,1).alias('CREY8090-CUO-IGU'),
    DF_T133OPC_CONS.value.substr(234,2).alias('CREY8090-TAS-CLC'),
    DF_T133OPC_CONS.value.substr(236,3).alias('CREY8090-MNT-CSD'),
    DF_T133OPC_CONS.value.substr(239,8).alias('CREY8090-FEC-ACT'),
    DF_T133OPC_CONS.value.substr(247,8).alias('CREY8090-FEC-TEO'),
    DF_T133OPC_CONS.value.substr(255,6).alias('CREY8090-FEC-OTO'),
    DF_T133OPC_CONS.value.substr(261,4).alias('CREY8090-UNI-GES'),
    DF_T133OPC_CONS.value.substr(265,10).alias('CREY8090-BLT-GAR'),
    DF_T133OPC_CONS.value.substr(275,1).alias('CREY8090-RIE-ORG'),
    DF_T133OPC_CONS.value.substr(276,4).alias('CREY8090-POR-FON'),
    DF_T133OPC_CONS.value.substr(280,3).alias('CREY8090-COD-CAI'),
    DF_T133OPC_CONS.value.substr(283,8).alias('CREY8090-FEC-FIR'),
    DF_T133OPC_CONS.value.substr(291,6).alias('CREY8090-LIN-CRD'),
    DF_T133OPC_CONS.value.substr(297,14).alias('CREY8090-MNT-NMN'),
    DF_T133OPC_CONS.value.substr(311,7).alias('CREY8090-TAS-TBJ'),
    DF_T133OPC_CONS.value.substr(318,14).alias('CREY8090-MNT-ACU'),
    DF_T133OPC_CONS.value.substr(332,14).alias('CREY8090-MTO-ACL'),
    DF_T133OPC_CONS.value.substr(346,1).alias('CREY8090-TIP-AVS'),
    DF_T133OPC_CONS.value.substr(347,15).alias('CREY8090-SDO-CPL-TEO'),
    DF_T133OPC_CONS.value.substr(362,15).alias('CREY8090-SDO-ORG'),
    DF_T133OPC_CONS.value.substr(377,15).alias('CREY8090-SDO-ORG-PES'),
    DF_T133OPC_CONS.value.substr(392,15).alias('CREY8090-SDO-VCD'),
    DF_T133OPC_CONS.value.substr(407,15).alias('CREY8090-SDO-VCD-PES'),
    DF_T133OPC_CONS.value.substr(422,15).alias('CREY8090-SDO-CBR-JUD'),
    DF_T133OPC_CONS.value.substr(437,15).alias('CREY8090-SDO-CBR-JUD-PE'),
    DF_T133OPC_CONS.value.substr(452,15).alias('CREY8090-SDO-CST'),
    DF_T133OPC_CONS.value.substr(467,15).alias('CREY8090-SDO-CST-PES'),
    DF_T133OPC_CONS.value.substr(482,3).alias('CREY8090-TIP-PMO')
)

print("Ingrese Regla de Negocios que desee aplicar (Para Esto debe conocer el nombre de las columnas):\n")
print("1.- Regla de Negocios rn_001 : Completitud sin Nulos o Vacíos\n")
print("2.- Regla de Negocios rn_003 : Número mayor o igual a 0\n")
opcion = int(input("Ingrese su opción: "))

#Creamos variable que tome el nombre de la columna de tipo String
Nom_Columna = "None"


while opcion != 0:
    if opcion == 1:
        print ("Ha ingresado a la regla de negocios rn_001\n")
        print (input("Introduzca Columna a aplicar regla de negocios: \n"))
    elif opcion == 2:
        print ()
    print("Ingrese nuevamente Regla de Negocios que desee aplicar (Para Esto debe conocer el nombre de las columnas):\n")
    print("1.- Regla Negocios rn_001 : Completitud sin Nulos o Vacíos")
    opcion = int(input("Ingrese su opción: "))
