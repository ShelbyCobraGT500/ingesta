# coding=utf-8
#CÓDIGO DE LA REGLA DE CALIDAD: RN001, RN002, RN003
#GLOSA: No puede venir en blanco, No debe tener nulos, No debe venir en blanco/ nulos
#COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
#PROBADO EN Pyspark
#EJEMPLO DE COMO APLICAR LA FUNCIÓN
#df_final = df_new.withColumn("rn001", rn001("<nombre columna en la cual se debe aplicar la regla>"))
#udf_rn001 = udf(rn001,StringType())


#definición de la función
import re

def rn001_completitud_sin_nulos(Input):
  #condicional que evaluá si cumple con los parametros establecidos, transforma el dato de Unicode a Ascii
  if re.search("\x00",Input) or re.search("NULL",Input):
    return 0 # si esta nulo ('NULL')"
  else:
    return 1 # en caso contrario
