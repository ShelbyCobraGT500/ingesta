# coding=utf-8
#CODIGO DE LA REGLA DE CALIDAD:RN009
#ABARCA REGLAS:
#   RN009 (ID=9)  = Numerico de largo 1
#   RN010 (ID=10) = Numerico de largo 2
#   RN011 (ID=11) = Numerico de largo 3
#   RN017 (ID=17) = Numerido de largo 15
#   RN012 (ID=12) = Numerico de largo 4
#   RN016 (ID=16) = Numerico de largo 11
#   RN013 (ID=13) = Numerico de largo 5
#   RN014 (ID=14) = Numerico de largo 9
#   RN015 (ID=15) = Numerico de largo 10
#   RN055 (ID=55) = Numerico de largo 7
#GLOSA: EVALUA QUE UNA VARIABLE SEA NUMERICA DE LARGO X
#COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
#PROBADO EN Pyspark
#FECHA MODIFICACION: 31/05/2018
#AUTOR: FELIPE ÁVALOS DÍAZ

#CREACIÓN UDF PARA LLAMAR A FUNCIÓN EN PYSAPRK
#df_final = df_new.withColumn("RN009",UDF_RN009(<nombre de las columnas en la cual se debe aplicar la regla>,x(donde x es el tamaño a evaluar)))
#UDF_RN009 = udf(RN009,StringType())

#definicion de la funcion para evaluar tamaño del Input
def RGL_GEN_RN009(Input,size):
    try:
        In = int(Input)
        tam = int(size)
        if len(str(In)) == tam:
            return 1
        else:
            return 0
    except ValueError:  
        return 0