package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN006
// GLOSA: Valores posibles F y M
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn033_valores_posibles_F_y_M_UDF = udf[String, String](rn033_valores_posibles_F_y_M)
// val df_new = df.withColumn("RN033", rn033_valores_posibles_F_y_M_UDF($"C4"))

def rn033_valores_posibles_F_y_M ( input : String) : String = try {
(List("F","M") contains input) match {
case true => "1"
case false => "0"
}
} catch {
case e: IllegalArgumentException => "0"
}
}