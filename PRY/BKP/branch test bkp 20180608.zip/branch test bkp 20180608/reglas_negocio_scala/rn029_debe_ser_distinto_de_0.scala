package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN029
// GLOSA: Debe ser distinto '0'
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn029_debe_ser_distinto_de_0_UDF = udf[String, String](rn029_debe_ser_distinto_de_0)
// val df_new = df.withColumn("RN033", rn029_debe_ser_distinto_de_0_UDF($"C4"))



def rn029_debe_ser_distinto_de_0 ( input : String) : String = {
input != "0" match {
case true => "1"
case false => "0"
}
}
}
