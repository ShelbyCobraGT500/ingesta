package reglas_negocio_scala
object funciones extends Serializable {
// CODIGO DE LA REGLA DE CALIDAD: RN006
// GLOSA: Debe ser distinto de 000
// COMPLEJIDAD: BAJA (porque aplica a solo un EDC)
// PROBADO EN SCALA SPARK util.Properties.versionNumberString=2.10.5
// EJEMPLO DE COMO APLICAR LA FUNCION
// val rn031_debe_ser_distinto_de_000_UDF = udf[String, String](rn031_debe_ser_distinto_de_000)
// val df_new = df.withColumn("RN033", rn031_debe_ser_distinto_de_000_UDF($"C4"))

def rn031_debe_ser_distinto_de_000 ( input : String) : String = {
input != "000" match {
case true => "1"
case false => "0"
}
}
}