# encoding=utf-8
def Filtro(Input1, Input2, Input3):
    print "\n"
    if Input1 == "" and Input2 == "Sin desarrollar":
        return "OK"
    else:
        return Input3